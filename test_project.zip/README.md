# test_project

Automated test package for **test_project**, generated with [Morvix](https://github.com/morvix/morvix).

## How to run (without Morvix)

Only Python 3 is required. Run your solution against the tests with:

```bash
./run.sh <your-solution>
```

Useful flags:

- `--group <name>` — run only cases from a specific group
- `--case <id>` — run a single case by id
- `--no-valgrind` — skip the memory checker even if it is installed
- `--diff` — show a side-by-side diff on failure

## How to run (with Morvix)

If you have [Morvix](https://github.com/morvix/morvix) installed, open it in this directory for the full interactive view:

```bash
morvix
```

## What the tests cover

No test cases are included in this package yet.

## How answers are judged

Outputs are compared after normalising whitespace (extra spaces and blank lines are ignored).

The program reads from **stdin** and writes to **stdout**.

Limits in force: wall-clock time: **10.0s**.

The memory checker is **not enabled** by default. Pass `--valgrind` to activate it, or use `--no-valgrind` to suppress the prompt.

## Disclaimer

These tests come from one student's own solution and one interpretation of the assignment.
There is no official answer key.
Passing all tests **does not prove correctness**.
Widespread disagreement across many independent solutions is the real signal that a test may be wrong.
